/** All DOM rendering. Every render reads the current case and redraws its region. */
import { priors, lik, update, observed, posterior, entropy, infoGain, likelihoodRatio } from "./bayes.js";
import { PRESETS } from "./data/cases.js";
import { store, save, C } from "./store.js";
import { $, esc, clamp, COLORS } from "./util.js";
import { t, num, P, ex, caseTitle, caseBrief, susName, susRole, clueText, caseName } from "./i18n.js";

export function colorOf(c, sid){ const i = c.suspects.findIndex(s=>s.id===sid); return COLORS[i % COLORS.length]; }

export function renderAll(){
  const c = C();
  if (!c.suspects.find(s=>s.id===c.selected)) c.selected = c.suspects[0] ? c.suspects[0].id : null;
  const post = posterior(c);
  renderCaseSel(); renderHero(c, post); renderLineup(c, post); renderClues(c);
  renderWhy(c); renderNext(c, post); renderTrail(c); renderNet(c);
  save();
}

export function renderCaseSel(){
  $("#caseSel").innerHTML = Object.keys(PRESETS).map(k =>
    `<option value="${k}" ${k===store.current?"selected":""}>${esc(caseName(k))}</option>`).join("");
}

export function renderHero(c, post){
  $("#caseTitle").textContent = caseTitle(c);
  $("#caseBrief").textContent = caseBrief(c);
  document.title = caseTitle(c) + " · " + t("appName");
  const v = $("#verdict");
  if (!c.suspects.length){ v.innerHTML = `<div class="lbl">${t("noSus")}</div><div class="who">${t("noSusHint")}</div>`; return; }
  const sorted = c.suspects.slice().sort((a,b)=>post[b.id]-post[a.id]);
  const top = sorted[0], p = post[top.id], n = observed(c).length;
  const second = sorted[1] ? post[sorted[1].id] : 0;
  let mood;
  if (n === 0) mood = t("mood0");
  else if (p < .35) mood = t("mood1");
  else if (p < .6) mood = t("mood2");
  else if (p < .85) mood = t("mood3", {x: num((p/Math.max(second,1e-9)).toFixed(1))});
  else mood = t("mood4");
  v.innerHTML = `<div class="lbl">${t("primeAfter", {n: num(n)})}</div>
    <div class="who">${esc(susName(top))}</div>
    <div class="pct">${t("likelyCulprit", {p: P(p)})} ${mood}</div>`;
}

export function renderLineup(c, post){
  const pr = priors(c);
  const lead = c.suspects.reduce((m,s)=>!m||post[s.id]>post[m.id]?s:m, null);
  $("#lineup").innerHTML = c.suspects.map(s => `
    <div class="suspect ${s.id===c.selected?"selected":""} ${lead&&s.id===lead.id&&observed(c).length?"leader":""}" data-sel="${s.id}" tabindex="0" role="button" aria-pressed="${s.id===c.selected}">
      <button class="btn quiet edit" data-editsus="${s.id}" aria-label="${esc(t("editName", {name: susName(s)}))}">${t("edit")}</button>
      <div class="nm"><span class="dot" style="background:${colorOf(c,s.id)}"></span>${esc(susName(s))}</div>
      <div class="rl">${esc(susRole(s))}</div>
      <div class="prob">${P(post[s.id])}<small>%</small></div>
      <div class="meter"><i style="width:${(post[s.id]*100).toFixed(1)}%"></i></div>
      <label class="prior">${t("priorPct", {p: P(pr[s.id])})} <input type="range" min="1" max="10" value="${s.prior}" data-prior="${s.id}" aria-label="${esc(t("priorFor", {name: susName(s)}))}"></label>
    </div>`).join("") + `<button class="suspect add-card" id="addSus">${t("addSus")}</button>`;
}

export function renderClues(c){
  const box = $("#clues");
  if (!c.clues.length){ box.innerHTML = `<div class="empty">${t("noClues")}</div>`; return; }
  box.innerHTML = c.clues.map((cl,i) => `
    <article class="clue ${cl.state}" id="clue-${cl.id}">
      <div class="ctop"><span class="tag">${t("exhibit", {x: ex(i)})}</span><span class="rel">${t("relPct", {p: num(Math.round(cl.rel*100))})}</span></div>
      <p class="ctext">${esc(clueText(cl))}</p>
      <div class="cfoot">
        <div class="seg" role="group" aria-label="${t("exStatus", {x: ex(i)})}">
          <button data-state="unknown" data-clue="${cl.id}" aria-pressed="${cl.state==="unknown"}">${t("unchecked")}</button>
          <button class="f" data-state="present" data-clue="${cl.id}" aria-pressed="${cl.state==="present"}">${t("found")}</button>
          <button data-state="absent" data-clue="${cl.id}" aria-pressed="${cl.state==="absent"}">${t("notFound")}</button>
        </div>
        <button class="btn quiet" data-editclue="${cl.id}">${t("editLiks")}</button>
      </div>
    </article>`).join("");
}

export function renderWhy(c){
  const s = c.suspects.find(x=>x.id===c.selected);
  const ul = $("#why");
  if (!s){ $("#whyTitle").textContent = t("whyH"); $("#whySub").textContent = t("whyNoSus"); ul.innerHTML=""; return; }
  $("#whyTitle").textContent = t("caseAgainst", {name: susName(s)});
  const obs = observed(c);
  if (!obs.length){ $("#whySub").textContent = t("whyNoObs"); ul.innerHTML=""; return; }
  $("#whySub").textContent = t("whyBars");
  const idx = id => c.clues.findIndex(x=>x.id===id);
  ul.innerHTML = obs.map(cl => {
    const lr = likelihoodRatio(c, cl, s.id), l2 = clamp(Math.log2(lr), -4, 4), w = Math.abs(l2)/4*50;
    const bar = l2 >= 0 ? `left:50%;width:${w}%;background:var(--string)` : `right:50%;width:${w}%;background:var(--muted)`;
    const txt = lr >= 1 ? t("toward", {x: num(lr.toFixed(1))}) : t("against", {x: num((1/lr).toFixed(1))});
    return `<li title="${esc(clueText(cl))}"><span class="ex">${ex(idx(cl.id))} ${cl.state==="present"?"✓":"✗"}</span><div class="diverge"><i style="${bar}"></i></div><span class="lr">${txt}</span></li>`;
  }).join("");
}

export function renderNext(c, post){
  const ul = $("#next");
  const un = c.clues.map((cl,i)=>({cl,i})).filter(x=>x.cl.state==="unknown");
  if (!un.length || c.suspects.length < 2){ ul.innerHTML = `<li style="display:block;color:var(--muted)">${c.clues.length ? t("allChecked") : t("addForTips")}</li>`; return; }
  const H = entropy(post);
  const ranked = un.map(x=>({...x, g:infoGain(post, x.cl)})).sort((a,b)=>b.g-a.g).slice(0,3);
  ul.innerHTML = ranked.map(x => `<li><span class="tag">${ex(x.i)}</span>
      <button data-goto="${x.cl.id}">${esc(clueText(x.cl))}</button>
      <span class="bits">${t("bits", {x: num(x.g.toFixed(2))})}${H>0?`, ${num(Math.round(x.g/H*100))}%`:""}</span></li>`).join("");
}

export function renderTrail(c){
  const ul = $("#trail"), obs = observed(c);
  if (!obs.length){ ul.innerHTML = `<li style="color:var(--muted)">${t("trailEmpty")}</li>`; return; }
  let d = priors(c);
  const stack = dist => `<div class="stack">${c.suspects.map(s=>`<i style="width:${(dist[s.id]*100).toFixed(2)}%;background:${colorOf(c,s.id)}" title="${esc(susName(s))} ${P(dist[s.id])}%"></i>`).join("")}</div>`;
  let html = `<li><div class="step"><span class="n">${num(0)}</span><span>${t("priorsOnly")}</span></div>${stack(d)}</li>`;
  obs.forEach((cl, k) => {
    const prev = d; d = update(d, cl, cl.state);
    let up=null, down=null;
    c.suspects.forEach(s => { const f = d[s.id]/prev[s.id]; if(!up||f>up.f) up={s,f}; if(!down||f<down.f) down={s,f}; });
    const i = c.clues.findIndex(x=>x.id===cl.id);
    html += `<li><div class="step"><span class="n">${num(k+1)}</span><span>${t(cl.state==="present"?"exFound":"exNotFound", {x: ex(i)})}</span></div>${stack(d)}
      <div class="note">${up.f>1.05?`${esc(susName(up.s))} ×${num(up.f.toFixed(2))}`:t("littleChange")}${down.f<.95?`; ${esc(susName(down.s))} ×${num(down.f.toFixed(2))}`:""}</div></li>`;
  });
  ul.innerHTML = html;
}

export function renderNet(c){
  const n = c.clues.length, col = 120, W = Math.max(680, n*col + 60), H = 330;
  const rx = W/2, ry = 52;
  const css = getComputedStyle(document.documentElement);
  const ink = css.getPropertyValue("--ink").trim(), rule = css.getPropertyValue("--rule").trim(),
        str = css.getPropertyValue("--string").trim(), card = css.getPropertyValue("--card").trim(),
        muted = css.getPropertyValue("--muted").trim(), tag = css.getPropertyValue("--tag").trim();
  const x0 = (W - n*col)/2 + col/2;
  let edges = "", nodes = "";
  c.clues.forEach((cl,i) => {
    const x = x0 + i*col, fy = 170, oy = 262, on = cl.state !== "unknown";
    const sc = on ? str : rule, sw = on ? 2.2 : 1.2, dash = on ? "" : `stroke-dasharray="4 4"`;
    edges += `<path d="M${rx},${ry+22} C${rx},${(ry+fy)/2} ${x},${(ry+fy)/2} ${x},${fy-22}" fill="none" stroke="${sc}" stroke-width="${sw}" ${dash}/>`;
    edges += `<line x1="${x}" y1="${fy+22}" x2="${x}" y2="${oy-18}" stroke="${sc}" stroke-width="${sw}" ${dash}/>`;
    nodes += `<circle cx="${x}" cy="${fy}" r="22" fill="${card}" stroke="${on?str:muted}" stroke-width="1.5"/>
      <text x="${x}" y="${fy+5}" text-anchor="middle" style="font-family:var(--type)" font-weight="700" font-size="14" fill="${ink}">${ex(i)}</text>
      <text x="${x+28}" y="${fy-14}" font-size="11" fill="${muted}">${t("fact")}</text>`;
    const lab = t(cl.state==="present" ? "lowFound" : cl.state==="absent" ? "lowNotFound" : "lowUnchecked");
    const fill = cl.state==="present" ? tag : card;
    nodes += `<g class="obs" data-cycle="${cl.id}" style="cursor:pointer" tabindex="0" role="button" aria-label="${t("reportAria", {x: ex(i), s: lab})}">
      <rect x="${x-50}" y="${oy-18}" width="100" height="36" rx="3" fill="${fill}" stroke="${on?str:muted}" stroke-width="1.5"/>
      <text x="${x}" y="${oy-1}" text-anchor="middle" font-size="12" font-weight="600" fill="${cl.state==="present"?"#2A2208":ink}">${t("report", {x: ex(i)})}</text>
      <text x="${x}" y="${oy+12}" text-anchor="middle" font-size="10.5" fill="${cl.state==="present"?"#2A2208":muted}">${lab} · ${num(Math.round(cl.rel*100))}%</text></g>`;
  });
  const root = `<rect x="${rx-70}" y="${ry-22}" width="140" height="44" rx="22" fill="${ink}"/>
    <text x="${rx}" y="${ry+6}" text-anchor="middle" font-size="16" font-weight="800" fill="${card}">${t("culprit")}</text>
    <text x="${rx+80}" y="${ry+4}" font-size="11" fill="${muted}">${t("possible", {n: num(c.suspects.length)})}</text>`;
  const empty = n ? "" : `<text x="${rx}" y="190" text-anchor="middle" font-size="14" fill="${muted}">${t("growNet")}</text>`;
  $("#net").innerHTML = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" style="font-family:var(--serif)" role="img" aria-label="${t("netAria", {n: num(n)})}">${edges}${root}${nodes}${empty}</svg>`;
}
