import { test } from "node:test";
import assert from "node:assert/strict";
import { priors, pReport, update, posterior, entropy, infoGain, likelihoodRatio } from "../src/bayes.js";
import { PRESETS, CASE_NAMES } from "../src/data/cases.js";
import { PRESETS_BN, CASE_NAMES_BN } from "../src/data/cases.bn.js";
import { letter } from "../src/util.js";

const near = (a, b, eps = 1e-9) => assert.ok(Math.abs(a - b) < eps, `${a} ≈ ${b}`);

function makeCase() {
  return {
    suspects: [
      { id: "a", name: "A", prior: 1 },
      { id: "b", name: "B", prior: 1 }
    ],
    clues: [{ id: "x", rel: 0.9, p: { a: 0.9, b: 0.1 }, state: "unknown", order: 0 }]
  };
}

test("priors normalise weights", () => {
  const c = makeCase();
  c.suspects[0].prior = 3;
  const p = priors(c);
  near(p.a, 0.75);
  near(p.b, 0.25);
});

test("pReport sums out the hidden fact", () => {
  const clue = { rel: 0.8, p: { a: 0.6 } };
  near(pReport(clue, "a"), 0.8 * 0.6 + 0.2 * 0.4);
});

test("a 50% reliable source tells you nothing", () => {
  const c = makeCase();
  c.clues[0].rel = 0.5;
  c.clues[0].state = "present";
  const post = posterior(c);
  near(post.a, 0.5);
});

test("Bayes update matches a hand calculation", () => {
  const c = makeCase();
  const post = update(priors(c), c.clues[0], "present");
  // P(found|a)=0.9*0.9+0.1*0.1=0.82, P(found|b)=0.9*0.1+0.1*0.9=0.18
  near(post.a, 0.82);
  near(post.b, 0.18);
});

test("posterior is independent of the order clues are marked", () => {
  const c = structuredClone(PRESETS.teaestate);
  c.clues.forEach((cl, i) => { cl.state = i % 2 ? "present" : "absent"; cl.order = i; });
  const p1 = posterior(c);
  c.clues.forEach((cl, i) => (cl.order = -i));
  const p2 = posterior(c);
  for (const k in p1) near(p1[k], p2[k], 1e-12);
});

test("posterior sums to one", () => {
  const c = structuredClone(PRESETS.shankhari);
  c.clues.forEach((cl) => { cl.state = "present"; cl.order = 1; });
  near(Object.values(posterior(c)).reduce((a, b) => a + b, 0), 1);
});

test("entropy of a uniform distribution over 4 is 2 bits", () => {
  near(entropy({ a: 0.25, b: 0.25, c: 0.25, d: 0.25 }), 2);
});

test("information gain is non-negative and zero for useless clues", () => {
  const c = makeCase();
  const d = priors(c);
  assert.ok(infoGain(d, c.clues[0]) > 0);
  near(infoGain(d, { rel: 0.5, p: { a: 0.9, b: 0.1 } }), 0);
});

test("likelihood ratio points toward the suspect the clue fits", () => {
  const c = makeCase();
  c.clues[0].state = "present";
  near(likelihoodRatio(c, c.clues[0], "a"), 0.82 / 0.18);
  assert.ok(likelihoodRatio(c, c.clues[0], "b") < 1);
});

test("every preset is well-formed", () => {
  for (const [key, c] of Object.entries(PRESETS)) {
    const ids = c.suspects.map((s) => s.id);
    assert.equal(new Set(ids).size, ids.length, `${key}: duplicate suspect ids`);
    for (const cl of c.clues) {
      assert.ok(cl.rel > 0 && cl.rel <= 1, `${key}/${cl.id}: rel out of range`);
      assert.deepEqual(Object.keys(cl.p).sort(), [...ids].sort(), `${key}/${cl.id}: p must cover every suspect`);
      for (const v of Object.values(cl.p)) assert.ok(v >= 0 && v <= 1, `${key}/${cl.id}: p out of range`);
    }
  }
});

test("every preset has a complete Bangla translation", () => {
  assert.deepEqual(Object.keys(PRESETS_BN).sort(), Object.keys(PRESETS).sort());
  assert.deepEqual(Object.keys(CASE_NAMES_BN).sort(), Object.keys(CASE_NAMES).sort());
  for (const [key, c] of Object.entries(PRESETS)) {
    const bn = PRESETS_BN[key];
    assert.ok(bn.title && bn.brief, `${key}: missing title or brief`);
    for (const s of c.suspects) assert.ok(bn.suspects[s.id]?.name && bn.suspects[s.id]?.role, `${key}/${s.id}: missing translation`);
    for (const cl of c.clues) assert.ok(bn.clues[cl.id], `${key}/${cl.id}: missing translation`);
  }
});

test("exhibit letters work with any alphabet", () => {
  assert.equal(letter(0), "A");
  assert.equal(letter(26), "AA");
  assert.equal(letter(0, "কখগ"), "ক");
  assert.equal(letter(3, "কখগ"), "কক");
});
