/** Entry point: wires up events and dialogs, then draws the first frame. */
import { priors, posterior } from "./bayes.js";
import { store, save, C, freshCase } from "./store.js";
import { $, esc, uid } from "./util.js";
import { renderAll, renderHero, renderWhy, renderNext, renderTrail, renderNet } from "./render.js";
import { lang, setLang, t, num, P, applyStatic, caseTitle, caseBrief, susName, susRole, clueText } from "./i18n.js";

/* ---------- Interaction ---------- */
function setState(id, st){
  const c = C(), cl = c.clues.find(x=>x.id===id); if (!cl) return;
  if (st !== "unknown" && cl.state === "unknown") cl.order = ++c.counter;
  if (st === "unknown") cl.order = 0;
  cl.state = st; renderAll();
}
document.addEventListener("click", e => {
  const t = e.target;
  const sb = t.closest("[data-state]"); if (sb){ setState(sb.dataset.clue, sb.dataset.state); return; }
  const ec = t.closest("[data-editclue]"); if (ec){ openClue(ec.dataset.editclue); return; }
  const es = t.closest("[data-editsus]"); if (es){ e.stopPropagation(); openSus(es.dataset.editsus); return; }
  if (t.closest("#addSus")){ openSus(null); return; }
  const cy = t.closest("[data-cycle]"); if (cy){ cycle(cy.dataset.cycle); return; }
  const go = t.closest("[data-goto]"); if (go){ const el = document.getElementById("clue-"+go.dataset.goto); if (el){ el.scrollIntoView({behavior:"smooth",block:"center"}); el.querySelector(".seg button.f").focus({preventScroll:true}); } return; }
  if (t.closest("input")) return;
  const sel = t.closest("[data-sel]"); if (sel){ C().selected = sel.dataset.sel; renderAll(); }
});
document.addEventListener("keydown", e => {
  if (e.key !== "Enter" && e.key !== " ") return;
  const cy = e.target.closest && e.target.closest("[data-cycle]"); if (cy){ e.preventDefault(); cycle(cy.dataset.cycle); return; }
  if (e.target.matches && e.target.matches("[data-sel]")){ e.preventDefault(); C().selected = e.target.dataset.sel; renderAll(); }
});
function cycle(id){
  const cl = C().clues.find(x=>x.id===id);
  const next = {unknown:"present", present:"absent", absent:"unknown"}[cl.state];
  setState(id, next);
  const el = document.querySelector(`[data-cycle="${id}"]`); if (el) el.focus();
}
document.addEventListener("input", e => {
  if (e.target.dataset && e.target.dataset.lk){ e.target.nextElementSibling.value = num(e.target.value) + "%"; return; }
  const pr = e.target.dataset && e.target.dataset.prior;
  if (pr){
    const s = C().suspects.find(x=>x.id===pr); s.prior = +e.target.value;
    const c = C(), post = posterior(c);
    renderHero(c, post); renderWhy(c); renderNext(c, post); renderTrail(c);
    // update lineup numbers in place so the slider keeps focus
    const p = priors(c);
    c.suspects.forEach(x => {
      const card = document.querySelector(`[data-sel="${x.id}"]`); if (!card) return;
      card.querySelector(".prob").innerHTML = `${P(post[x.id])}<small>%</small>`;
      card.querySelector(".meter i").style.width = (post[x.id]*100).toFixed(1)+"%";
      card.querySelector(".prior").firstChild.nodeValue = t("priorPct", {p: P(p[x.id])}) + " ";
    });
    save();
  }
});
document.addEventListener("change", e => { if (e.target.dataset && e.target.dataset.prior) renderAll(); });

$("#caseSel").addEventListener("change", e => { store.current = e.target.value; renderAll(); });
$("#clearEv").addEventListener("click", () => { const c = C(); c.clues.forEach(x=>{x.state="unknown";x.order=0;}); c.counter=0; renderAll(); });
$("#resetCase").addEventListener("click", () => {
  if (confirm(t("confirmReset"))){ store.cases[store.current] = freshCase(store.current); renderAll(); }
});

/* Clue dialog */
let editingClue = null, shownClueText = "";
function openClue(id){
  const c = C();
  editingClue = id ? c.clues.find(x=>x.id===id) : {id:uid("c"), text:"", rel:.8, p:{}, state:"unknown", order:0, isNew:true};
  $("#clueDlgTitle").textContent = t(editingClue.isNew ? "addClue" : "editClue");
  $("#clueDel").style.visibility = editingClue.isNew ? "hidden" : "visible";
  $("#clueText").value = shownClueText = clueText(editingClue);
  $("#clueRel").value = Math.round(editingClue.rel*100); $("#clueRelOut").value = num($("#clueRel").value) + "%";
  $("#clueLiks").innerHTML = c.suspects.map(s => {
    const v = Math.round((editingClue.p[s.id] ?? .5)*100);
    return `<label class="rangerow"><span>${esc(susName(s))}</span><input type="range" min="1" max="99" value="${v}" data-lk="${s.id}"><output>${num(v)}%</output></label>`;
  }).join("") || `<p style="color:var(--muted)">${t("addSusFirst")}</p>`;
  $("#clueDlg").showModal(); $("#clueText").focus();
}
$("#clueRel").addEventListener("input", e => $("#clueRelOut").value = num(e.target.value) + "%");
$("#clueCancel").addEventListener("click", () => $("#clueDlg").close());
$("#clueSave").addEventListener("click", () => {
  const text = $("#clueText").value.trim();
  if (!text){ $("#clueText").focus(); $("#clueText").placeholder = t("clueNeedsText"); return; }
  const c = C(); if (text !== shownClueText) editingClue.text = text; editingClue.rel = +$("#clueRel").value/100;
  document.querySelectorAll("[data-lk]").forEach(r => editingClue.p[r.dataset.lk] = +r.value/100);
  if (editingClue.isNew){ delete editingClue.isNew; c.clues.push(editingClue); }
  $("#clueDlg").close(); renderAll();
});
$("#clueDel").addEventListener("click", () => {
  const c = C(); c.clues = c.clues.filter(x=>x.id!==editingClue.id); $("#clueDlg").close(); renderAll();
});
$("#addClue").addEventListener("click", () => openClue(null));

/* Suspect dialog */
let editingSus = null;
function openSus(id){
  const c = C();
  editingSus = id ? c.suspects.find(x=>x.id===id) : {id:uid("s"), name:"", role:"", prior:5, isNew:true};
  $("#susDlgTitle").textContent = t(editingSus.isNew ? "addSus" : "editSus");
  $("#susDel").style.visibility = editingSus.isNew ? "hidden" : "visible";
  $("#susName").value = susName(editingSus); $("#susRole").value = susRole(editingSus);
  $("#susPrior").value = editingSus.prior; $("#susPriorOut").value = num(editingSus.prior);
  $("#susDlg").showModal(); $("#susName").focus();
}
$("#susPrior").addEventListener("input", e => $("#susPriorOut").value = num(e.target.value));
$("#susCancel").addEventListener("click", () => $("#susDlg").close());
$("#susSave").addEventListener("click", () => {
  const name = $("#susName").value.trim();
  if (!name){ $("#susName").focus(); $("#susName").placeholder = t("susNeedsName"); return; }
  const c = C(), role = $("#susRole").value.trim();
  if (name !== susName(editingSus)) editingSus.name = name;
  if (role !== susRole(editingSus)) editingSus.role = role; editingSus.prior = +$("#susPrior").value;
  if (editingSus.isNew){ delete editingSus.isNew; c.suspects.push(editingSus); c.clues.forEach(cl => cl.p[editingSus.id] = .5); c.selected = editingSus.id; }
  $("#susDlg").close(); renderAll();
});
$("#susDel").addEventListener("click", () => {
  const c = C();
  if (c.suspects.length <= 1){ alert(t("needOneSus")); return; }
  c.suspects = c.suspects.filter(x=>x.id!==editingSus.id);
  c.clues.forEach(cl => delete cl.p[editingSus.id]);
  $("#susDlg").close(); renderAll();
});

/* Case dialog */
$("#editCase").addEventListener("click", () => { $("#caseTitleIn").value = caseTitle(C()); $("#caseBriefIn").value = caseBrief(C()); $("#caseDlg").showModal(); });
$("#caseCancel").addEventListener("click", () => $("#caseDlg").close());
$("#caseSave").addEventListener("click", () => {
  const c = C(), title = $("#caseTitleIn").value.trim(), brief = $("#caseBriefIn").value.trim();
  if (title && title !== caseTitle(c)) c.title = title;
  if (brief !== caseBrief(c)) c.brief = brief; $("#caseDlg").close(); renderAll();
});

/* Language */
$("#langBtn").addEventListener("click", () => { setLang(lang === "bn" ? "en" : "bn"); applyStatic(); renderAll(); });

window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => renderNet(C()));
applyStatic();
renderAll();
