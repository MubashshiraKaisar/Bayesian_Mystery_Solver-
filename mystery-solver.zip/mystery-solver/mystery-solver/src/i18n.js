/** Interface language: English (default) or Bangla. Strings, digits, exhibit letters and preset text. */
import { PRESETS, CASE_NAMES } from "./data/cases.js";
import { PRESETS_BN, CASE_NAMES_BN } from "./data/cases.bn.js";
import { store } from "./store.js";
import { letter, pct } from "./util.js";

const LANG_KEY = "mystery-solver-lang";

const STRINGS = {
  en: {
    appName: "Mystery Solver",
    brand: "Mystery Solver <span>/</span> Bangladesh casebook",
    langBtn: "বাংলা", langBtnLabel: "বাংলায় দেখুন",
    caseLbl: "Case", editCase: "Edit case", clearEv: "Clear evidence", resetCase: "Reset case",
    lineupH: "The lineup",
    lineupSub: "Each figure is the probability that this person is the culprit, given the evidence you’ve marked. Drag the prior weight to say who looked suspicious before any clues came in. Select a suspect to see which clues point at them.",
    boardH: "Evidence board",
    boardSub: "Mark each clue as found or not found once you’ve checked it. Unchecked clues don’t affect the result.",
    addClue: "Add clue", whyH: "Why this suspect",
    nextH: "Check next",
    nextSub: "Unchecked clues ranked by how much they’re expected to narrow things down, measured in bits of information.",
    trailH: "Reasoning trail", trailSub: "How belief shifted as each clue was marked, in order.",
    netH: "The network",
    netSub: "The culprit determines what really happened (hidden facts). Each fact reaches you through a source that may be wrong. Red string marks the paths carrying evidence. Click a report to cycle its state.",
    how1: "<strong style=\"color:var(--ink)\">How the inference works.</strong> For every clue, each suspect has a number: if they did it, how likely is the underlying fact to be true? A source reliability of r means a true fact gets reported with probability r and a false one with probability 1 − r, so the chance of seeing a report given suspect s is r·p + (1 − r)(1 − p). The posterior multiplies each suspect’s prior by the likelihood of every checked clue and normalises. Inference is exact, by enumeration over the culprit node with the hidden facts summed out.",
    how2: "The “why” panel shows each clue’s likelihood ratio: how much more likely the observation is if the selected suspect did it than if someone else did, weighted by the priors.",
    editClue: "Edit clue", clueTextLbl: "What was found", relLbl: "Source reliability",
    relHelp: "How far you trust the source. 50% means the report tells you nothing; 99% means it’s almost certainly accurate.",
    likLbl: "If this suspect did it, how likely is the fact to be true?",
    likHelp: "High means the clue fits them; low means it points away from them.",
    delClue: "Delete clue", cancel: "Cancel", saveClue: "Save clue",
    editSus: "Edit suspect", addSus: "Add suspect", nameLbl: "Name", roleLbl: "Role or motive", priorLbl: "Prior weight",
    priorHelp: "How suspicious they look before any evidence, from 1 to 10.",
    delSus: "Remove suspect", saveSus: "Save suspect",
    caseTitleLbl: "Case title", briefLbl: "Brief", saveCase: "Save case",
    confirmReset: "Reset this case to its original suspects and clues? Your edits will be lost.",
    addSusFirst: "Add suspects first.", clueNeedsText: "Describe the clue before saving.",
    susNeedsName: "Give the suspect a name.", needOneSus: "A case needs at least one suspect.",
    noSus: "No suspects yet", noSusHint: "Add someone to the lineup",
    mood0: "No evidence checked yet, so this is just your prior.",
    mood1: "The field is still wide open.",
    mood2: "A lead is forming, but it isn’t safe to accuse.",
    mood3: "A strong lead, {x}× likelier than the next suspect.",
    mood4: "The evidence points firmly at one person.",
    primeAfter: n => `Prime suspect after ${n} clue${n === "1" ? "" : "s"}`,
    likelyCulprit: "<b>{p}%</b> likely the culprit.",
    edit: "Edit", editName: "Edit {name}", priorPct: "Prior {p}%", priorFor: "Prior weight for {name}",
    noClues: "No clues on the board. Add one to start reasoning about who did it.",
    exhibit: "Exhibit {x}", relPct: "Source reliability {p}%", exStatus: "Status of exhibit {x}",
    unchecked: "Unchecked", found: "Found", notFound: "Not found", editLiks: "Edit likelihoods",
    caseAgainst: "The case against {name}",
    whyNoSus: "Add a suspect to see how the evidence bears on them.",
    whyNoObs: "Mark a clue as found or not found to see how it bears on this suspect.",
    whyBars: "Bars right of centre point toward this suspect; bars left point away.",
    toward: "{x}× toward", against: "{x}× against",
    allChecked: "Every clue has been checked.", addForTips: "Add clues to get suggestions.",
    bits: "{x} bits",
    trailEmpty: "Nothing yet. The trail fills in as you mark clues.",
    priorsOnly: "Priors only", exFound: "Exhibit {x} found", exNotFound: "Exhibit {x} not found",
    littleChange: "Little change",
    fact: "fact", lowFound: "found", lowNotFound: "not found", lowUnchecked: "unchecked",
    report: "{x} report", reportAria: "Exhibit {x} report: {s}. Activate to change.",
    culprit: "Culprit", possible: "{n} possible values", growNet: "Add a clue to grow the network.",
    netAria: "Bayesian network: culprit node linked to {n} hidden facts, each with an observed report"
  },
  bn: {
    appName: "রহস্যভেদ",
    brand: "রহস্যভেদ <span>/</span> বাংলাদেশের তদন্তের খাতা",
    langBtn: "English", langBtnLabel: "Switch to English",
    caseLbl: "মামলা", editCase: "মামলা সম্পাদনা", clearEv: "প্রমাণ মুছুন", resetCase: "মামলা রিসেট",
    lineupH: "সন্দেহভাজনদের তালিকা",
    lineupSub: "প্রতিটি সংখ্যা দেখায়, আপনার চিহ্নিত প্রমাণ অনুযায়ী এই ব্যক্তির অপরাধী হওয়ার সম্ভাবনা কত। কোনো সূত্র পাওয়ার আগে কাকে সন্দেহজনক মনে হয়েছিল, তা বোঝাতে পূর্ব-ওজনের স্লাইডার টানুন। কোন সূত্রগুলো কার দিকে ইঙ্গিত করে দেখতে একজন সন্দেহভাজন বেছে নিন।",
    boardH: "প্রমাণের বোর্ড",
    boardSub: "প্রতিটি সূত্র যাচাই করার পর সেটি পাওয়া গেছে কি না চিহ্নিত করুন। যাচাই না করা সূত্র ফলাফলে কোনো প্রভাব ফেলে না।",
    addClue: "সূত্র যোগ করুন", whyH: "কেন এই সন্দেহভাজন",
    nextH: "এরপর যাচাই করুন",
    nextSub: "যাচাই না করা সূত্রগুলো সাজানো হয়েছে কোনটি সন্দেহের পরিসর কতটা ছোট করবে বলে আশা করা যায় তার ভিত্তিতে, তথ্যের বিটে মেপে।",
    trailH: "যুক্তির ধারা", trailSub: "প্রতিটি সূত্র চিহ্নিত করার সাথে সাথে ধারণা কীভাবে বদলেছে, ক্রমানুসারে।",
    netH: "নেটওয়ার্ক",
    netSub: "অপরাধী কে, তার ওপর নির্ভর করে আসলে কী ঘটেছিল (লুকানো তথ্য)। প্রতিটি তথ্য আপনার কাছে পৌঁছায় এমন এক উৎসের মাধ্যমে, যা ভুলও হতে পারে। লাল সুতো দেখায় কোন পথে প্রমাণ আসছে। কোনো রিপোর্টে ক্লিক করে তার অবস্থা বদলান।",
    how1: "<strong style=\"color:var(--ink)\">হিসাবটা কীভাবে হয়।</strong> প্রতিটি সূত্রে প্রত্যেক সন্দেহভাজনের একটি সংখ্যা থাকে: তিনি অপরাধী হলে মূল তথ্যটি সত্য হওয়ার সম্ভাবনা কত? উৎসের নির্ভরযোগ্যতা r মানে, সত্য তথ্য r সম্ভাবনায় আর মিথ্যা তথ্য 1 − r সম্ভাবনায় রিপোর্ট হয়। তাই সন্দেহভাজন s অপরাধী হলে রিপোর্টটি দেখার সম্ভাবনা r·p + (1 − r)(1 − p)। পরবর্তী সম্ভাবনা পেতে প্রত্যেকের পূর্ব-সম্ভাবনাকে যাচাই করা প্রতিটি সূত্রের সম্ভাবনা দিয়ে গুণ করে মোট ১ বানানো হয়। হিসাবটি নির্ভুল: লুকানো তথ্যগুলো যোগ করে বাদ দিয়ে অপরাধী-নোডের সব মান গুনে দেখা হয়।",
    how2: "“কেন” প্যানেলে প্রতিটি সূত্রের সম্ভাবনা-অনুপাত দেখানো হয়: বাছাই করা সন্দেহভাজন অপরাধী হলে পর্যবেক্ষণটি অন্য কেউ অপরাধী হওয়ার তুলনায় কত গুণ বেশি সম্ভাব্য, পূর্ব-সম্ভাবনা দিয়ে ভারিত।",
    editClue: "সূত্র সম্পাদনা", clueTextLbl: "কী পাওয়া গেছে", relLbl: "উৎসের নির্ভরযোগ্যতা",
    relHelp: "উৎসকে আপনি কতটা বিশ্বাস করেন। ৫০% মানে রিপোর্টটি কিছুই জানায় না; ৯৯% মানে এটি প্রায় নিশ্চিতভাবে সঠিক।",
    likLbl: "এই সন্দেহভাজন অপরাধী হলে তথ্যটি সত্য হওয়ার সম্ভাবনা কত?",
    likHelp: "বেশি মানে সূত্রটি তার সাথে মেলে; কম মানে সূত্রটি তার থেকে দূরে ইঙ্গিত করে।",
    delClue: "সূত্র মুছুন", cancel: "বাতিল", saveClue: "সূত্র সংরক্ষণ",
    editSus: "সন্দেহভাজন সম্পাদনা", addSus: "সন্দেহভাজন যোগ করুন", nameLbl: "নাম", roleLbl: "ভূমিকা বা উদ্দেশ্য", priorLbl: "পূর্ব-ওজন",
    priorHelp: "কোনো প্রমাণ পাওয়ার আগে তাকে কতটা সন্দেহজনক মনে হয়, ১ থেকে ১০-এর মধ্যে।",
    delSus: "সন্দেহভাজন বাদ দিন", saveSus: "সন্দেহভাজন সংরক্ষণ",
    caseTitleLbl: "মামলার শিরোনাম", briefLbl: "বিবরণ", saveCase: "মামলা সংরক্ষণ",
    confirmReset: "এই মামলাটি মূল সন্দেহভাজন ও সূত্রে ফিরিয়ে নেবেন? আপনার সম্পাদনাগুলো হারিয়ে যাবে।",
    addSusFirst: "আগে সন্দেহভাজন যোগ করুন।", clueNeedsText: "সংরক্ষণের আগে সূত্রটি লিখুন।",
    susNeedsName: "সন্দেহভাজনের একটি নাম দিন।", needOneSus: "একটি মামলায় অন্তত একজন সন্দেহভাজন থাকতে হবে।",
    noSus: "এখনো কোনো সন্দেহভাজন নেই", noSusHint: "তালিকায় কাউকে যোগ করুন",
    mood0: "এখনো কোনো প্রমাণ যাচাই হয়নি, তাই এটি শুধু আপনার পূর্বধারণা।",
    mood1: "এখনো সবার দিকেই সন্দেহের সুযোগ খোলা।",
    mood2: "একটা সূত্র দানা বাঁধছে, তবে এখনই কাউকে দোষী বলা নিরাপদ নয়।",
    mood3: "জোরালো সন্দেহ: পরের সন্দেহভাজনের চেয়ে {x} গুণ বেশি সম্ভাব্য।",
    mood4: "প্রমাণ দৃঢ়ভাবে একজনের দিকেই ইঙ্গিত করছে।",
    primeAfter: n => `${n}টি সূত্রের পর প্রধান সন্দেহভাজন`,
    likelyCulprit: "<b>{p}%</b> সম্ভাবনা ইনিই অপরাধী।",
    edit: "সম্পাদনা", editName: "{name} সম্পাদনা", priorPct: "পূর্ব {p}%", priorFor: "{name}-এর পূর্ব-ওজন",
    noClues: "বোর্ডে কোনো সূত্র নেই। কে অপরাধী তা নিয়ে ভাবা শুরু করতে একটি সূত্র যোগ করুন।",
    exhibit: "আলামত {x}", relPct: "উৎসের নির্ভরযোগ্যতা {p}%", exStatus: "আলামত {x}-এর অবস্থা",
    unchecked: "যাচাই হয়নি", found: "পাওয়া গেছে", notFound: "পাওয়া যায়নি", editLiks: "সম্ভাবনা সম্পাদনা",
    caseAgainst: "{name}-এর বিরুদ্ধে প্রমাণ",
    whyNoSus: "প্রমাণ কার ওপর কেমন প্রভাব ফেলে দেখতে একজন সন্দেহভাজন যোগ করুন।",
    whyNoObs: "এই সন্দেহভাজনের ওপর সূত্রের প্রভাব দেখতে কোনো সূত্রকে ‘পাওয়া গেছে’ বা ‘পাওয়া যায়নি’ হিসেবে চিহ্নিত করুন।",
    whyBars: "মাঝখানের ডানের বার এই সন্দেহভাজনের দিকে ইঙ্গিত করে; বামের বার তার থেকে দূরে।",
    toward: "{x}× সন্দেহ বাড়ায়", against: "{x}× সন্দেহ কমায়",
    allChecked: "সব সূত্র যাচাই করা হয়েছে।", addForTips: "পরামর্শ পেতে সূত্র যোগ করুন।",
    bits: "{x} বিট",
    trailEmpty: "এখনো কিছু নেই। সূত্র চিহ্নিত করলে ধারাটি তৈরি হবে।",
    priorsOnly: "শুধু পূর্বধারণা", exFound: "আলামত {x} পাওয়া গেছে", exNotFound: "আলামত {x} পাওয়া যায়নি",
    littleChange: "সামান্য পরিবর্তন",
    fact: "তথ্য", lowFound: "পাওয়া গেছে", lowNotFound: "পাওয়া যায়নি", lowUnchecked: "যাচাই হয়নি",
    report: "{x} রিপোর্ট", reportAria: "আলামত {x}-এর রিপোর্ট: {s}। বদলাতে চাপুন।",
    culprit: "অপরাধী", possible: "{n} জন সন্দেহভাজন", growNet: "নেটওয়ার্ক বাড়াতে একটি সূত্র যোগ করুন।",
    netAria: "বেইজীয় নেটওয়ার্ক: অপরাধী-নোড {n}টি লুকানো তথ্যের সাথে যুক্ত, প্রতিটির একটি রিপোর্ট আছে"
  }
};

export let lang = "en";
try { if (localStorage.getItem(LANG_KEY) === "bn") lang = "bn"; } catch (e) { /* storage unavailable */ }

export function setLang(l) {
  lang = l;
  try { localStorage.setItem(LANG_KEY, l); } catch (e) { /* ignore */ }
}

/** Look up an interface string and fill {placeholders}. Values should already be formatted with num(). */
export function t(key, vars = {}) {
  const s = STRINGS[lang][key] ?? STRINGS.en[key];
  if (typeof s === "function") return s(vars.n);
  return s.replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? "");
}

const BN_DIGITS = "০১২৩৪৫৬৭৮৯";
/** Write a number (or numeric string) in Bangla digits when Bangla is on. */
export function num(x) {
  const s = String(x);
  return lang === "bn" ? s.replace(/[0-9]/g, (d) => BN_DIGITS[d]) : s;
}
export const P = (x) => num(pct(x));

const BN_LETTERS = "কখগঘচছজঝটঠডঢতথদধনপফবভমযরলশসহ";
/** Exhibit label: A, B, C… or ক, খ, গ… */
export const ex = (i) => (lang === "bn" ? letter(i, BN_LETTERS) : letter(i));

/* Preset text. A built-in case keeps its English text in storage; in Bangla mode we show the
   translation as long as the stored text still matches the original (i.e. the user hasn't edited it). */
const findById = (arr, id) => arr && arr.find((x) => x.id === id);
function local(stored, en, bn) {
  return lang === "bn" && bn != null && stored === en ? bn : stored;
}
const base = () => PRESETS[store.current];
const tr = () => PRESETS_BN[store.current] || {};

export const caseTitle = (c) => local(c.title, base()?.title, tr().title);
export const caseBrief = (c) => local(c.brief, base()?.brief, tr().brief);
export const susName = (s) => local(s.name, findById(base()?.suspects, s.id)?.name, tr().suspects?.[s.id]?.name);
export const susRole = (s) => local(s.role, findById(base()?.suspects, s.id)?.role, tr().suspects?.[s.id]?.role);
export const clueText = (cl) => local(cl.text, findById(base()?.clues, cl.id)?.text, tr().clues?.[cl.id]);

/** Name of a case for the case menu. */
export function caseName(key) {
  const names = lang === "bn" ? CASE_NAMES_BN : CASE_NAMES;
  if (key !== "blank") return names[key];
  const title = store.cases.blank.title;
  return title === PRESETS.blank.title || title === PRESETS_BN.blank.title ? names.blank : title;
}

/** Fill the static page text marked with data-i18n / data-i18n-html. */
export function applyStatic() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach((el) => (el.textContent = t(el.dataset.i18n)));
  document.querySelectorAll("[data-i18n-html]").forEach((el) => (el.innerHTML = t(el.dataset.i18nHtml)));
  const b = document.getElementById("langBtn");
  b.setAttribute("aria-label", t("langBtnLabel"));
  b.lang = lang === "bn" ? "en" : "bn";
}
