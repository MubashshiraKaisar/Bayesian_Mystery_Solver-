/**
 * Bayesian inference engine for Mystery Solver.
 *
 * Network structure (per clue k):
 *
 *     Culprit ──> Fact_k ──> Report_k
 *
 *   P(Fact_k = true  | Culprit = s) = clue.p[s]
 *   P(Report = found | Fact = true) = clue.rel
 *   P(Report = found | Fact = false) = 1 - clue.rel
 *
 * Fact_k is hidden, so it is summed out:
 *   P(Report = found | s) = rel * p + (1 - rel) * (1 - p)
 *
 * The posterior over the culprit is computed exactly by enumeration.
 * Pure functions only: no DOM access, so this file is unit-testable in Node.
 */
import { clamp } from "./util.js";

/** Normalised prior distribution from suspects' prior weights. */
export function priors(c) {
  const tot = c.suspects.reduce((a, s) => a + s.prior, 0) || 1;
  const d = {};
  c.suspects.forEach((s) => (d[s.id] = s.prior / tot));
  return d;
}

/** P(report = found | culprit = sid), hidden fact summed out. */
export function pReport(clue, sid) {
  const p = clamp(clue.p[sid] ?? 0.5, 0.01, 0.99);
  const r = clue.rel;
  return r * p + (1 - r) * (1 - p);
}

/** Likelihood of an observed outcome ("present" | "absent") given culprit sid. */
export function lik(clue, sid, outcome) {
  const q = pReport(clue, sid);
  return outcome === "present" ? q : 1 - q;
}

export function normalise(d) {
  const t = Object.values(d).reduce((a, b) => a + b, 0) || 1;
  for (const k in d) d[k] /= t;
  return d;
}

/** One step of Bayes' rule: returns a new distribution. */
export function update(dist, clue, outcome) {
  const n = {};
  for (const k in dist) n[k] = dist[k] * lik(clue, k, outcome);
  return normalise(n);
}

/** Checked clues in the order they were marked. */
export function observed(c) {
  return c.clues.filter((x) => x.state !== "unknown").sort((a, b) => a.order - b.order);
}

/** Posterior P(culprit | all checked clues). */
export function posterior(c) {
  let d = priors(c);
  observed(c).forEach((cl) => (d = update(d, cl, cl.state)));
  return d;
}

/** Shannon entropy in bits. */
export function entropy(d) {
  let h = 0;
  for (const k in d) if (d[k] > 0) h -= d[k] * Math.log2(d[k]);
  return h;
}

/** Expected reduction in entropy (bits) from checking an unchecked clue. */
export function infoGain(dist, clue) {
  let p1 = 0;
  for (const k in dist) p1 += dist[k] * pReport(clue, k);
  const h1 = entropy(update(dist, clue, "present"));
  const h0 = entropy(update(dist, clue, "absent"));
  return entropy(dist) - (p1 * h1 + (1 - p1) * h0);
}

/**
 * Likelihood ratio of a checked clue for suspect sid versus everyone else,
 * with the others weighted by their priors.
 */
export function likelihoodRatio(c, clue, sid) {
  const pr = priors(c);
  const ls = lik(clue, sid, clue.state);
  const others = c.suspects.filter((x) => x.id !== sid);
  if (!others.length) return 1;
  const ow = others.reduce((a, x) => a + pr[x.id], 0);
  const lo = others.reduce((a, x) => a + pr[x.id] * lik(clue, x.id, clue.state), 0) / ow;
  return ls / lo;
}
