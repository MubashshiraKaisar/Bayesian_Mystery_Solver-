# Mystery Solver

A Bayesian-network detective's casebook. Mark clues as found or not found, and the app works out how likely each suspect is to be the culprit. It also shows which unchecked clue would narrow the field the most.

Every built-in case is set in Bangladesh: a poisoning at a tea estate in Srimangal, a gold theft in Old Dhaka's Shankhari Bazar, and a death on the night launch from Sadarghat to Barishal. The interface is in English. The **বাংলা** button in the top bar switches everything, case text included, to Bangla, and the choice is remembered.

Interface text lives in `src/i18n.js`. The Bangla text for the built-in cases is in `src/data/cases.bn.js`, keyed by the same ids as `src/data/cases.js`. If you add a case, add its translation too: the tests check that every case has one.

## Run it in VS Code

You need [Node.js](https://nodejs.org) 18 or newer.

1. Unzip the project and open the `mystery-solver` folder in VS Code (**File → Open Folder…**).
2. Open the terminal (**Terminal → New Terminal**) and run:

   ```bash
   npm install
   npm run dev
   ```

3. Your browser opens at http://localhost:5173. Edits to the files reload the page automatically.

**Other ways to run it**

- **Debugger:** press **F5** and choose *Debug in Chrome* (or *Debug in Edge*). The dev server starts and you can set breakpoints in `src/`.
- **Without Node:** install the recommended *Live Server* extension, right-click `index.html`, and choose *Open with Live Server*.
  (Opening `index.html` by double-clicking won't work, because browsers block JavaScript modules loaded from `file://`.)

## Scripts

| Command           | What it does                                        |
| ----------------- | --------------------------------------------------- |
| `npm run dev`     | Start the dev server with live reload               |
| `npm test`        | Run the unit tests for the inference engine         |
| `npm run build`   | Build a static site into `dist/`                    |
| `npm run preview` | Serve the built site to check it before deploying   |

## Project layout

```
mystery-solver/
├── index.html            Page markup and dialogs
├── src/
│   ├── main.js           Entry point: event handling and dialogs
│   ├── render.js         Draws the lineup, evidence board, panels and network
│   ├── bayes.js          Inference engine (pure functions, no DOM)
│   ├── store.js          Case state, saved to localStorage
│   ├── util.js           Small helpers
│   ├── i18n.js           Bangla/English interface text, digits and exhibit letters
│   ├── styles.css        All styling, light and dark themes
│   ├── data/cases.js     Built-in mysteries; add your own here
│   └── data/cases.bn.js  Bangla text for the built-in mysteries
├── tests/bayes.test.js   Unit tests (Node's built-in test runner)
├── vite.config.js
└── .vscode/              Tasks, launch configs, recommended extensions
```

## How the inference works

Each clue adds a small chain to the network:

```
Culprit ──> Fact (hidden: what really happened) ──> Report (what you observed)
```

- `p[s]` is P(fact is true | suspect s did it).
- `rel` is the source's reliability. A true fact is reported with probability `rel`, and a false one with probability `1 − rel`.
- The hidden fact is summed out, so P(report found | s) = rel·p + (1 − rel)(1 − p).
- The posterior is prior × the product of the likelihoods of all checked clues, normalised. The calculation is exact, by enumeration.
- **Check next** ranks unchecked clues by expected information gain, meaning the expected drop in entropy measured in bits.
- **The case against…** shows each clue's likelihood ratio for the selected suspect against everyone else, weighted by the priors.

## Adding your own mystery

Add an entry to `PRESETS` and `CASE_NAMES` in `src/data/cases.js`:

```js
myCase: {
  title: "The Missing Nakshi Kantha",
  brief: "What happened…",
  suspects: [{ id: "rina", name: "Rina Akter", role: "Shop assistant", prior: 3 }],
  clues: [{ id: "k1", text: "Indigo thread caught on the back gate.", rel: 0.8, p: { rina: 0.7 } }]
}
```

You can also build a case in the app itself by choosing **Blank case**. Saved progress lives in your browser's localStorage. **Reset case** restores the original version.
