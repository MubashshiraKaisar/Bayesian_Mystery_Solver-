/** Case state and persistence (browser localStorage). */
import { PRESETS } from "./data/cases.js";
import { clone } from "./util.js";

const STORE_KEY = "mystery-solver-v1";

export function freshCase(id) {
  const c = clone(PRESETS[id]);
  c.clues.forEach((cl) => {
    cl.state = "unknown";
    cl.order = 0;
  });
  c.selected = c.suspects[0] ? c.suspects[0].id : null;
  c.counter = 0;
  return c;
}

export let store = { current: "teaestate", cases: {} };

try {
  const raw = localStorage.getItem(STORE_KEY);
  if (raw) {
    const s = JSON.parse(raw);
    if (s && s.cases) store = s;
  }
} catch (e) {
  /* storage unavailable: start fresh */
}
Object.keys(PRESETS).forEach((k) => {
  if (!store.cases[k]) store.cases[k] = freshCase(k);
});
if (!PRESETS[store.current]) store.current = "teaestate";

export function save() {
  try {
    localStorage.setItem(STORE_KEY, JSON.stringify(store));
  } catch (e) {
    /* ignore */
  }
}

/** The case currently on screen. */
export const C = () => store.cases[store.current];
