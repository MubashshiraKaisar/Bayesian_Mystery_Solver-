// Built-in mystery scenarios.
// p[suspectId] = P(fact is true | that suspect is the culprit)
// rel = source reliability: P(report matches the truth)

export const PRESETS = {
  teaestate: {
    title: "Monsoon at Shonali Tea Estate",
    brief: "At dawn in Srimangal, the cook found Rafiq Chowdhury, manager of Shonali Tea Estate, dead in his bungalow. A cold cup of cha sat beside him. The doctor suspects ground datura seeds. Heavy rain had cut the estate off from town all night.",
    suspects: [
      {id:"nasrin", name:"Nasrin Chowdhury", role:"His wife, wanted to move back to Dhaka", prior:3},
      {id:"kamal", name:"Kamal Hossain", role:"Assistant manager, keeps the leaf-weight books", prior:3},
      {id:"mithu", name:"Mithu Das", role:"Cook, twenty years with the family", prior:2},
      {id:"tanvir", name:"Tanvir Ahmed", role:"Nephew visiting from Dhaka, in debt", prior:2},
      {id:"farzana", name:"Dr. Farzana Haque", role:"Estate doctor, quarrelled with him over clinic funds", prior:2}
    ],
    clues: [
      {id:"t1", text:"The datura seeds were ground fine and came from the bush behind the factory. Whoever did it knew the plant.", rel:.85, p:{nasrin:.3,kamal:.6,mithu:.7,tanvir:.1,farzana:.8}},
      {id:"t2", text:"Muddy gumboot prints lead from the tea rows up to the bungalow verandah.", rel:.7, p:{nasrin:.05,kamal:.8,mithu:.3,tanvir:.5,farzana:.1}},
      {id:"t3", text:"The cha tray sat unattended on the verandah for ten minutes after 9 pm.", rel:.6, p:{nasrin:.7,kamal:.8,mithu:.2,tanvir:.8,farzana:.7}},
      {id:"t4", text:"Rafiq had emailed head office about a 2,000 kg gap in the leaf-weight records.", rel:.9, p:{nasrin:.3,kamal:.95,mithu:.3,tanvir:.3,farzana:.3}},
      {id:"t5", text:"The chowkidar heard a woman arguing with Rafiq at about 8:30 pm.", rel:.65, p:{nasrin:.85,kamal:.15,mithu:.15,tanvir:.15,farzana:.7}},
      {id:"t6", text:"Rafiq sent Tk 3 lakh by bKash to Tanvir’s number the day before, with the note “last time”.", rel:.95, p:{nasrin:.3,kamal:.3,mithu:.3,tanvir:.9,farzana:.3}},
      {id:"t7", text:"Whoever did it knew the bungalow would go dark when the 9 pm load-shedding started.", rel:.7, p:{nasrin:.7,kamal:.85,mithu:.8,tanvir:.2,farzana:.6}}
    ]
  },
  shankhari: {
    title: "The Shankhari Bazar Gold",
    brief: "On the second night of Eid, while Old Dhaka was half empty, 40 bhori of gold went missing from the safe at Banik Jewellers in Shankhari Bazar. The shutter was still padlocked in the morning.",
    suspects: [
      {id:"shyamal", name:"Shyamal Banik", role:"Owner’s son, wants to emigrate", prior:2},
      {id:"jahangir", name:"Jahangir Alam", role:"Karigar, works the gold in the back room", prior:3},
      {id:"shirin", name:"Shirin Akter", role:"Shop accountant", prior:2},
      {id:"babul", name:"Babul Mia", role:"Night darwan, owes money to a lender", prior:3},
      {id:"selim", name:"Selim Reza", role:"Rival dealer from Tanti Bazar", prior:2}
    ],
    clues: [
      {id:"g1", text:"The safe was opened with its combination. It wasn’t forced.", rel:.9, p:{shyamal:.9,jahangir:.4,shirin:.7,babul:.3,selim:.1}},
      {id:"g2", text:"A rickshaw-puller saw a man carrying a heavy tiffin carrier down the lane at 2 am.", rel:.55, p:{shyamal:.5,jahangir:.6,shirin:.05,babul:.7,selim:.5}},
      {id:"g3", text:"The CCTV recorder was unplugged “because of a power cut”, but the block had power all night.", rel:.8, p:{shyamal:.6,jahangir:.3,shirin:.5,babul:.8,selim:.2}},
      {id:"g4", text:"Small, freshly melted gold bars turned up with a Tanti Bazar wholesaler two days later.", rel:.6, p:{shyamal:.3,jahangir:.8,shirin:.2,babul:.3,selim:.85}},
      {id:"g5", text:"The stock ledger had been overstating the gold in the safe for months.", rel:.85, p:{shyamal:.5,jahangir:.2,shirin:.9,babul:.1,selim:.1}},
      {id:"g6", text:"Shyamal had booked a flight to Toronto for the week after Eid.", rel:.9, p:{shyamal:.85,jahangir:.3,shirin:.3,babul:.3,selim:.3}},
      {id:"g7", text:"The lane’s street dogs didn’t bark that night, so whoever came was someone they knew.", rel:.5, p:{shyamal:.8,jahangir:.8,shirin:.7,babul:.9,selim:.1}},
      {id:"g8", text:"A goldsmith’s blowpipe and a smear of borax were left beside the safe.", rel:.75, p:{shyamal:.1,jahangir:.9,shirin:.05,babul:.1,selim:.3}}
    ]
  },
  launch: {
    title: "Death on the Night Launch to Barishal",
    brief: "The launch MV Sonar Tori left Sadarghat at 9 pm. When it docked at Barishal at dawn, rice-mill owner Abdul Mannan Sikder was found dead in his VIP cabin with a head wound. The cabin door was locked from the inside.",
    suspects: [
      {id:"rokeya", name:"Rokeya Sikder", role:"His wife, in the cabin next door", prior:3},
      {id:"faruk", name:"Faruk Talukder", role:"Business partner, the mill deal had just collapsed", prior:3},
      {id:"sumon", name:"Sumon", role:"Cabin boy, holds the spare keys", prior:2},
      {id:"aziz", name:"Aziz Mollah", role:"Launch master, owed Mannan money", prior:1},
      {id:"lipi", name:"Lipi Begum", role:"His sister, in a dispute over ancestral land", prior:2}
    ],
    clues: [
      {id:"l1", text:"The cabin was locked from inside, but the crew’s spare key had been moved from its hook.", rel:.85, p:{rokeya:.5,faruk:.2,sumon:.9,aziz:.7,lipi:.2}},
      {id:"l2", text:"At the 1 am stop in Chandpur, a passenger got off for twenty minutes and came back aboard.", rel:.6, p:{rokeya:.3,faruk:.7,sumon:.2,aziz:.2,lipi:.3}},
      {id:"l3", text:"Pages of a land deed (dolil) were torn out of the victim’s briefcase.", rel:.8, p:{rokeya:.5,faruk:.3,sumon:.1,aziz:.1,lipi:.9}},
      {id:"l4", text:"There was a fresh paan stain on the victim’s collar, though he never chewed paan.", rel:.7, p:{rokeya:.1,faruk:.8,sumon:.5,aziz:.7,lipi:.6}},
      {id:"l5", text:"Mannan’s phone shows a missed call from Faruk at 12:50 am.", rel:.9, p:{rokeya:.35,faruk:.85,sumon:.35,aziz:.35,lipi:.35}},
      {id:"l6", text:"His gold chain and wallet were left behind, so it wasn’t a robbery.", rel:.9, p:{rokeya:.85,faruk:.85,sumon:.2,aziz:.85,lipi:.85}},
      {id:"l7", text:"The blow was struck in thick fog, when the foghorn drowns out any noise, so the killer knew the crew’s routine.", rel:.6, p:{rokeya:.4,faruk:.4,sumon:.8,aziz:.9,lipi:.4}}
    ]
  },
  blank: {
    title: "Untitled case",
    brief: "Describe what happened. Then add your suspects and the clues you’ve gathered.",
    suspects: [
      {id:"a", name:"Suspect A", role:"Add a role or motive", prior:5},
      {id:"b", name:"Suspect B", role:"Add a role or motive", prior:5}
    ],
    clues: []
  }
};
export const CASE_NAMES = {teaestate:"Monsoon at Shonali Tea Estate", shankhari:"The Shankhari Bazar Gold", launch:"Death on the Night Launch to Barishal", blank:"Blank case"};
