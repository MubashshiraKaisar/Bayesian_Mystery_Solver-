export const COLORS = ["#2E6A7E","#B42F28","#C9962B","#5E7D4E","#6B5A8E","#8A6A4F","#3F8C8A","#9A4F6B","#4C5F9E","#7A7F3A"];

export const $ = (s) => document.querySelector(s);
export const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
export const clone = (o) => JSON.parse(JSON.stringify(o));
export const uid = (p) => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
export const clamp = (x, a, b) => Math.min(b, Math.max(a, x));

/** 0 -> A, 25 -> Z, 26 -> AA. Pass another alphabet to label with its letters instead. */
export function letter(i, alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ") {
  const chars = [...alphabet], n = chars.length;
  let s = "";
  i++;
  while (i > 0) {
    const m = (i - 1) % n;
    s = chars[m] + s;
    i = Math.floor((i - 1) / n);
  }
  return s;
}

/** Format a probability as a percentage string without the % sign. */
export function pct(x) {
  if (x * 100 >= 99.5 && x < 1) return ">99";
  if (x * 100 < 0.5 && x > 0) return "<1";
  return String(Math.round(x * 100));
}
